/*\
title: toString.js
type: application/javascript
module-type: library

OwnProperty test B

\*/
